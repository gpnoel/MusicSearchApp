# MusicSearchApp
## Author: Graigor Pierre-Noel

# Instructions

There is no further work needed to use the application. Just open up the index.html file and use the application by searching up an artist.

Features include, pagination, detailed page on a click of a specific track (after searching an artist), and page responsiveness.

# LICENSE
[MIT](https://github.com/gpnoel/MusicSearchApp/blob/master/LICENSE)